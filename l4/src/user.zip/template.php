<table border="1" width="100%" height="100%">
    <tr height="10%">
        <td colspan="3">
           <?php
              include "blocks/header.php";
            ?>
        </td>
    </tr>
    <tr>
        <td width="15%">Левое меню</td>
        <td>
        <?php
              include "blocks/content.php";
            ?>
        </td>
        <td width="15%">Правое меню</td>
    </tr>
    <tr  height="10%">
        <td colspan="3">
            Подвал сайта
        </td>
    </tr>
</table>