<?
define("MYSQL_SERVER","localhost");
define("MYSQL_LOGIN","root");
define("MYSQL_PASSWORD","");
define("MYSQL_DB","catalog");

define("DIR_BIG","img/");
define("DIR_SMALL","imgMini/");

define("COLS",3);
