-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Час створення: Жов 22 2020 р., 10:58
-- Версія сервера: 10.3.22-MariaDB
-- Версія PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База даних: `test`
--

-- --------------------------------------------------------

--
-- Структура таблиці `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `small_url` varchar(128) NOT NULL,
  `big_url` varchar(128) NOT NULL,
  `size` int(16) NOT NULL,
  `photo_shows` int(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `images`
--

INSERT INTO `images` (`id`, `name`, `small_url`, `big_url`, `size`, `photo_shows`) VALUES
(21, '5961f5b35dc26.jpg', 'public/images/small_images/5961f5b35dc26.jpg', 'public/images/big_images/5961f5b35dc26.jpg', 124, 45),
(22, '3f0765e61b28bb8b96ca5c9ea1da3b00.jpg', 'public/images/small_images/3f0765e61b28bb8b96ca5c9ea1da3b00.jpg', 'public/images/big_images/3f0765e61b28bb8b96ca5c9ea1da3b00.jpg', 955, 20),
(23, 'images (1).jpg', 'public/images/small_images/images (1).jpg', 'public/images/big_images/images (1).jpg', 13, 15),
(24, 'unnamed.jpg', 'public/images/small_images/unnamed.jpg', 'public/images/big_images/unnamed.jpg', 106, 1),
(25, 'lake-irene-1679708__340.jpg', 'public/images/small_images/lake-irene-1679708__340.jpg', 'public/images/big_images/lake-irene-1679708__340.jpg', 62, 3),
(26, 'images.jpg', 'public/images/small_images/images.jpg', 'public/images/big_images/images.jpg', 14, 2),
(27, 'images (4).jpg', 'public/images/small_images/images (4).jpg', 'public/images/big_images/images (4).jpg', 13, 19),
(28, 'images (3).jpg', 'public/images/small_images/images (3).jpg', 'public/images/big_images/images (3).jpg', 9, 15),
(29, 'images (2).jpg', 'public/images/small_images/images (2).jpg', 'public/images/big_images/images (2).jpg', 10, 7),
(30, 'depositphotos_25569791-stock-photo-flowers-mountains-ald-lake.jpg', 'public/images/small_images/depositphotos_25569791-stock-photo-flowers-mountains-ald-lake.jpg', 'public/images/big_images/depositphotos_25569791-stock-photo-flowers-mountains-ald-lake.jpg', 77, 29),
(31, '3f0765e61b28bb8b96ca5c9ea1da3b00.jpg', 'public/images/small_images/3f0765e61b28bb8b96ca5c9ea1da3b00.jpg', 'public/images/big_images/3f0765e61b28bb8b96ca5c9ea1da3b00.jpg', 955, 9),
(32, '1161643.jpeg', 'public/images/small_images/1161643.jpeg', 'public/images/big_images/1161643.jpeg', 36, 2),
(33, 'lake-irene-1679708__340.jpg', 'public/images/small_images/lake-irene-1679708__340.jpg', 'public/images/big_images/lake-irene-1679708__340.jpg', 62, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `image` varchar(128) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `image`, `description`) VALUES
(30, 'Samsung j788', '4555', '180030-01-600x600.jpg', 'Описание samsung j788'),
(31, 'Iphone x10', '27999', 'Apple-iPhone-11-Pro-Space-Gray-01-600x600.jpg', 'Описание описание описание'),
(32, 'Lenovo a319', '2999', '180714-01-600x600.jpg', 'Описание lenovo 215'),
(34, 'Nokia 3210', '999', 'Nokia-230-Dark-Silver-1-600x600.jpg', 'Описание'),
(37, 'Lenovo k351', '2999', 'Y72019_Black_01-600x600.jpg', 'Описание для телефона Lenovo k351');

-- --------------------------------------------------------

--
-- Структура таблиці `review`
--

CREATE TABLE `review` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `review` varchar(64) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `review`
--

INSERT INTO `review` (`id`, `name`, `email`, `review`, `date`) VALUES
(11, 'Артур Олар', 'arturolar56195046@gmail.com', 'Тестовый отзыв', '2020-10-20 19:27:24'),
(12, 'Test', 'test@gmail.com', 'Test', '2020-10-20 20:40:21'),
(13, 'Артур Олар', 'arturolar56195046@gmail.com', 'Отзыв', '2020-10-22 07:17:35');

-- --------------------------------------------------------

--
-- Структура таблиці `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(32) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `birthday` date NOT NULL,
  `sex` varchar(16) NOT NULL,
  `role` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `email`, `birthday`, `sex`, `role`) VALUES
(14, 'admin', '827ccb0eea8a706c4c34a16891f84e7bqwfbnvs43t6qwdasfd23', 'arturolar56195046@gmail.com', '1996-08-10', 'мужской', 'admin'),
(15, 'user', 'efe6398127928f1b2e9ef3207fb82663qwfbnvs43t6qwdasfd23', 'arturolar@gmail.com', '1997-08-10', 'мужской', 'user'),
(16, 'user123', '827ccb0eea8a706c4c34a16891f84e7bqwfbnvs43t6qwdasfd23', 'arturolar5619046@gmail.com', '1996-08-10', 'мужской', 'user'),
(17, 'user123456', 'e10adc3949ba59abbe56e057f20f883eqwfbnvs43t6qwdasfd23', 'asfsf@gmail.com', '5040-04-10', 'мужской', 'user'),
(18, 'qweqdas', '827ccb0eea8a706c4c34a16891f84e7bqwfbnvs43t6qwdasfd23', 'test@gmail.com', '0500-05-05', 'мужской', 'user');

--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `review`
--
ALTER TABLE `review`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для збережених таблиць
--

--
-- AUTO_INCREMENT для таблиці `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT для таблиці `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT для таблиці `review`
--
ALTER TABLE `review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблиці `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
